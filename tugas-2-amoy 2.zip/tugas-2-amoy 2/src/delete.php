<?php
require_once 'db.php';
$id = $_GET['id'] ?? null;

if (!$id || !filter_var($id, FILTER_VALIDATE_INT)) {
    header("Location: index.php?status=gagal"); exit();
}

$stmt = $conn->prepare("DELETE FROM barang_dipinjam WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        header("Location: index.php?status=sukses_hapus");
    } else {
        header("Location: index.php?status=gagal_hapus_tidak_ditemukan"); // atau status=gagal saja
    }
} else {
    header("Location: index.php?status=gagal");
}
$stmt->close();
exit();
?>