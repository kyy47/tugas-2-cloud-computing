<?php
// app/db.php
$host = getenv('DB_HOST') ?: 'sql200.infinityfree.com-kinn'; // Nama service MariaDB
$dbname = getenv('DB_NAME') ?: 'if0_39081664_habit_tracker_db';
$username = getenv('DB_USER') ?: 'if0_39081664';
$password = getenv('DB_PASSWORD') ?: 'sNOXI1tEf8hbo9O';
$port = getenv('DB_PORT') ?: '3306'; // Port default MariaDB

$conn = new mysqli($host, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error . " (Host: ".$host.")");
}

if (!$conn->set_charset("utf8mb4")) {
    // opsional: printf("Error loading character set utf8mb4: %s\n", $conn->error);
}
?>