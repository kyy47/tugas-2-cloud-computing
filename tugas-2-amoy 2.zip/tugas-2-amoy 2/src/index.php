<?php
require_once 'db.php';
$sql = "SELECT id, nama_barang, nama_peminjam, 
               DATE_FORMAT(tanggal_pinjam, '%d %b %Y') AS tgl_pinjam, 
               DATE_FORMAT(tanggal_kembali_estimasi, '%d %b %Y') AS tgl_estimasi,
               DATE_FORMAT(tanggal_dikembalikan_aktual, '%d %b %Y') AS tgl_aktual,
               catatan 
        FROM barang_dipinjam ORDER BY tanggal_pinjam DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pelacak Peminjaman Barang - Amdy</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Daftar Barang Dipinjam - AMDY</h1>
        <a href="create.php" class="btn btn-add">Catat Peminjaman Baru</a>

        <?php if (isset($_GET['status'])): ?>
            <div class="message <?php echo strpos($_GET['status'], 'sukses') !== false ? 'success' : 'error'; ?>">
                <?php
                if ($_GET['status'] == 'sukses_tambah') echo 'Data peminjaman berhasil ditambahkan!';
                if ($_GET['status'] == 'sukses_edit') echo 'Data peminjaman berhasil diperbarui!';
                if ($_GET['status'] == 'sukses_hapus') echo 'Data peminjaman berhasil dihapus!';
                if ($_GET['status'] == 'gagal') echo 'Operasi gagal, silakan coba lagi.';
                ?>
            </div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Nama Barang</th>
                    <th>Dipinjam Oleh</th>
                    <th>Tgl Pinjam</th>
                    <th>Estimasi Kembali</th>
                    <th>Aktual Kembali</th>
                    <th>Catatan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['nama_barang']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_peminjam']); ?></td>
                        <td><?php echo htmlspecialchars($row['tgl_pinjam']); ?></td>
                        <td><?php echo htmlspecialchars($row['tgl_estimasi'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($row['tgl_aktual'] ?? 'Belum Kembali'); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($row['catatan'] ?? '-')); ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-edit">Edit</a>
                            <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-delete" onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="7">Belum ada barang yang dicatat dipinjam.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>