<?php
require_once 'db.php';
$errors = [];
$nama_barang = $nama_peminjam = $tanggal_pinjam = $tanggal_kembali_estimasi = $catatan = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_barang = trim($_POST['nama_barang']);
    $nama_peminjam = trim($_POST['nama_peminjam']);
    $tanggal_pinjam = $_POST['tanggal_pinjam'];
    $tanggal_kembali_estimasi = !empty($_POST['tanggal_kembali_estimasi']) ? $_POST['tanggal_kembali_estimasi'] : null;
    $catatan = trim($_POST['catatan']);

    if (empty($nama_barang)) $errors[] = "Nama barang wajib diisi.";
    if (empty($nama_peminjam)) $errors[] = "Nama peminjam wajib diisi.";
    if (empty($tanggal_pinjam)) $errors[] = "Tanggal pinjam wajib diisi.";

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO barang_dipinjam (nama_barang, nama_peminjam, tanggal_pinjam, tanggal_kembali_estimasi, catatan) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nama_barang, $nama_peminjam, $tanggal_pinjam, $tanggal_kembali_estimasi, $catatan);
        if ($stmt->execute()) {
            header("Location: index.php?status=sukses_tambah");
            exit();
        } else {
            $errors[] = "Gagal menyimpan data: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Catat Peminjaman Baru - Amdy</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Catat Peminjaman Baru</h1>
        <?php if (!empty($errors)): ?>
            <div class="message error">
                <ul><?php foreach ($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul>
            </div>
        <?php endif; ?>
        <form action="create.php" method="post" class="form-group">
            <label for="nama_barang">Nama Barang:</label>
            <input type="text" id="nama_barang" name="nama_barang" value="<?php echo htmlspecialchars($nama_barang); ?>" required>

            <label for="nama_peminjam">Dipinjam Oleh:</label>
            <input type="text" id="nama_peminjam" name="nama_peminjam" value="<?php echo htmlspecialchars($nama_peminjam); ?>" required>

            <label for="tanggal_pinjam">Tanggal Pinjam:</label>
            <input type="date" id="tanggal_pinjam" name="tanggal_pinjam" value="<?php echo htmlspecialchars($tanggal_pinjam); ?>" required>

            <label for="tanggal_kembali_estimasi">Estimasi Tanggal Kembali (Opsional):</label>
            <input type="date" id="tanggal_kembali_estimasi" name="tanggal_kembali_estimasi" value="<?php echo htmlspecialchars($tanggal_kembali_estimasi); ?>">
            
            <label for="catatan">Catatan (Opsional):</label>
            <textarea id="catatan" name="catatan"><?php echo htmlspecialchars($catatan); ?></textarea>

            <button type="submit" class="btn btn-add">Simpan</button>
            <a href="index.php" class="btn btn-back">Kembali</a>
        </form>
    </div>
</body>
</html>