<?php
require_once 'db.php';
$errors = [];
$id = $_GET['id'] ?? null;

if (!$id || !filter_var($id, FILTER_VALIDATE_INT)) {
    header("Location: index.php?status=gagal"); exit();
}

$nama_barang = $nama_peminjam = $tanggal_pinjam = $tanggal_kembali_estimasi = $tanggal_dikembalikan_aktual = $catatan = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_post = $_POST['id']; // ambil id dari hidden input
    $nama_barang = trim($_POST['nama_barang']);
    $nama_peminjam = trim($_POST['nama_peminjam']);
    $tanggal_pinjam = $_POST['tanggal_pinjam'];
    $tanggal_kembali_estimasi = !empty($_POST['tanggal_kembali_estimasi']) ? $_POST['tanggal_kembali_estimasi'] : null;
    $tanggal_dikembalikan_aktual = !empty($_POST['tanggal_dikembalikan_aktual']) ? $_POST['tanggal_dikembalikan_aktual'] : null;
    $catatan = trim($_POST['catatan']);

    if (empty($nama_barang)) $errors[] = "Nama barang wajib diisi.";
    if (empty($nama_peminjam)) $errors[] = "Nama peminjam wajib diisi.";
    if (empty($tanggal_pinjam)) $errors[] = "Tanggal pinjam wajib diisi.";
    
    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE barang_dipinjam SET nama_barang=?, nama_peminjam=?, tanggal_pinjam=?, tanggal_kembali_estimasi=?, tanggal_dikembalikan_aktual=?, catatan=? WHERE id=?");
        $stmt->bind_param("ssssssi", $nama_barang, $nama_peminjam, $tanggal_pinjam, $tanggal_kembali_estimasi, $tanggal_dikembalikan_aktual, $catatan, $id_post);
        if ($stmt->execute()) {
            header("Location: index.php?status=sukses_edit");
            exit();
        } else {
            $errors[] = "Gagal memperbarui data: " . $stmt->error;
        }
        $stmt->close();
    }
} else {
    $stmt_select = $conn->prepare("SELECT * FROM barang_dipinjam WHERE id = ?");
    $stmt_select->bind_param("i", $id);
    $stmt_select->execute();
    $result = $stmt_select->get_result();
    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $nama_barang = $row['nama_barang'];
        $nama_peminjam = $row['nama_peminjam'];
        $tanggal_pinjam = $row['tanggal_pinjam'];
        $tanggal_kembali_estimasi = $row['tanggal_kembali_estimasi'];
        $tanggal_dikembalikan_aktual = $row['tanggal_dikembalikan_aktual'];
        $catatan = $row['catatan'];
    } else {
        header("Location: index.php?status=gagal"); exit();
    }
    $stmt_select->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Peminjaman - </title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Edit Data Peminjaman</h1>
        <?php if (!empty($errors)): ?>
            <div class="message error">
                <ul><?php foreach ($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul>
            </div>
        <?php endif; ?>
        <form action="edit.php?id=<?php echo $id; ?>" method="post" class="form-group">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <label for="nama_barang">Nama Barang:</label>
            <input type="text" id="nama_barang" name="nama_barang" value="<?php echo htmlspecialchars($nama_barang); ?>" required>

            <label for="nama_peminjam">Dipinjam Oleh:</label>
            <input type="text" id="nama_peminjam" name="nama_peminjam" value="<?php echo htmlspecialchars($nama_peminjam); ?>" required>

            <label for="tanggal_pinjam">Tanggal Pinjam:</label>
            <input type="date" id="tanggal_pinjam" name="tanggal_pinjam" value="<?php echo htmlspecialchars($tanggal_pinjam); ?>" required>

            <label for="tanggal_kembali_estimasi">Estimasi Tanggal Kembali (Opsional):</label>
            <input type="date" id="tanggal_kembali_estimasi" name="tanggal_kembali_estimasi" value="<?php echo htmlspecialchars($tanggal_kembali_estimasi ?? ''); ?>">
            
            <label for="tanggal_dikembalikan_aktual">Tanggal Aktual Dikembalikan (Opsional):</label>
            <input type="date" id="tanggal_dikembalikan_aktual" name="tanggal_dikembalikan_aktual" value="<?php echo htmlspecialchars($tanggal_dikembalikan_aktual ?? ''); ?>">

            <label for="catatan">Catatan (Opsional):</label>
            <textarea id="catatan" name="catatan"><?php echo htmlspecialchars($catatan); ?></textarea>

            <button type="submit" class="btn btn-edit">Simpan Perubahan</button>
            <a href="index.php" class="btn btn-back">Kembali</a>
        </form>
    </div>
</body>
</html>