-- init.sql

-- Tabel: barang_dipinjam
CREATE TABLE IF NOT EXISTS barang_dipinjam (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_barang VARCHAR(255) NOT NULL,
    nama_peminjam VARCHAR(255) NOT NULL,
    tanggal_pinjam DATE NOT NULL,
    tanggal_kembali_estimasi DATE,
    tanggal_dikembalikan_aktual DATE NULL, -- Bisa NULL jika belum dikembalikan
    catatan TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Memasukkan minimal 2 (dua) record sebagai data awal (DML)
INSERT INTO barang_dipinjam (nama_barang, nama_peminjam, tanggal_pinjam, tanggal_kembali_estimasi, catatan) VALUES
('Buku Pemrograman Web Lanjutan', 'Andi', '2025-05-10', '2025-05-24', 'Untuk referensi tugas akhir.'),
('Charger Laptop Universal', 'Budi', '2025-05-15', '2025-05-18', 'Charger Budi rusak.');